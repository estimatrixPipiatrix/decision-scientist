#!/bin/bash
Rscript todoStatus.R
display statusPlot.jpg
